 <!-- app.vue -->
<template>
  <div>
    <NuxtPage />
  </div>
</template>
